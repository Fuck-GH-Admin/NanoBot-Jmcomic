# src/plugins/chatbot/matchers/admin.py

from nonebot import on_message
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, MessageSegment
from nonebot.params import EventPlainText
from nonebot.log import logger

from..services.permission_service import PermissionService

# 实例化服务
perm_srv = PermissionService()

# 优先级 5：必须高于普通聊天(10) 以便拦截指令
admin_cmd = on_message(priority=5, block=False)

@admin_cmd.handle()
async def handle_admin_cmd(bot: Bot, event: GroupMessageEvent, text: str = EventPlainText()):
    # 0. 基础过滤：仅群聊（虽然类型提示已约束，但运行时再校验更稳妥）
    if not isinstance(event, GroupMessageEvent):
        return

    text = text.strip()
    if not text: return

    # 1. 权限预检
    # 获取发送者在群内的角色 (owner/admin/member)
    user_id = str(event.user_id)
    sender_info = await bot.get_group_member_info(
        group_id=event.group_id, 
        user_id=event.user_id
    )
    sender_role = sender_info.get("role", "member")

    # 检查是否有权使用管理指令
    # 注意：这里我们不直接 reject，因为如果用户只是在聊天中提到“踢人”但没权限，
    # 我们应该放行给后续的聊天 matcher，而不是报错。
    # 只有当确实是管理指令格式时，才进行权限拦截。
    has_perm = perm_srv.has_command_privilege(user_id, sender_role)

    # ================= 指令解析 =================

    # --- 1. 踢人指令 ---
    if text.startswith(("踢", "kick ", "移除")):
        # 提取目标：所有被 @ 的人
        target_ids = [int(seg.data["qq"]) for seg in event.message if seg.type == "at"]
        if not target_ids:
            return # 没 @ 人，可能只是普通聊天，放行
        
        if not has_perm:
            await admin_cmd.finish("⚠️ 你没有权限执行踢人操作。")

        # 执行
        msgs = []
        for tid in target_ids:
            res = await perm_srv.kick_user(bot, event.group_id, tid)
            msgs.append(res)
        
        await admin_cmd.finish("\n".join(msgs))

    # --- 2. 禁言/解禁指令 ---
    elif text.startswith(("禁言", "解禁", "ban ", "unban ", "mute ")):
        is_unban = text.startswith(("解禁", "unban"))
        
        target_ids = [int(seg.data["qq"]) for seg in event.message if seg.type == "at"]
        if not target_ids:
            return 
        
        if not has_perm:
            await admin_cmd.finish("⚠️ 你没有权限执行禁言操作。")

        # 解析时间（仅禁言需要）
        duration = 0
        if not is_unban:
            # 移除指令前缀和 @部分，剩下的就是时间描述
            # 简单处理：直接把整个文本传进去，正则会自动提取数字+单位
            duration = perm_srv.parse_duration(text)

        msgs = []
        for tid in target_ids:
            res = await perm_srv.ban_user(
                bot, 
                event.group_id, 
                tid, 
                duration, 
                operator_id=user_id
            )
            msgs.append(res)
        
        await admin_cmd.finish("\n".join(msgs))

    # --- 3. AI 审计指令 (审判) ---
    elif text.startswith(("审判", "审计", "audit")):
        target_ids = [int(seg.data["qq"]) for seg in event.message if seg.type == "at"]
        if not target_ids:
            return

        if not has_perm:
            # 普通用户也可以申请审计，但可以通过配置限制
            # 这里假设仅管理员可主动触发
            await admin_cmd.finish("⚠️ 仅管理员可发起 AI 审计。")

        await admin_cmd.send("🕵️ AI 正在调取卷宗进行审计，请稍候...")
        
        msgs = []
        for tid in target_ids:
            res = await perm_srv.ai_audit_and_punish(bot, event.group_id, tid)
            msgs.append(res)
        
        await admin_cmd.finish("\n".join(msgs))

    # --- 4. 退群指令 ---
    elif text in ["退群", "主动退群", "leave"]:
        # 这是一个高危操作，必须严格检查 Superuser 或 群主
        is_superuser = perm_srv.is_superuser(user_id)
        is_owner = (sender_role == "owner")
        
        if is_superuser or is_owner:
            await admin_cmd.send("收到指令，Bot 正在退出群聊...")
            await bot.set_group_leave(group_id=event.group_id)
        else:
            await admin_cmd.finish("⚠️ 权限不足：仅群主或超级管理员可让 Bot 退群。")