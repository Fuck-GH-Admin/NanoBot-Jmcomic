from nonebot import on_command
from nonebot.adapters.onebot.v11 import Bot, MessageEvent, MessageSegment
from nonebot.params import CommandArg
from nonebot.adapters import Message

from ..services.drawing_service import DrawingService

draw_srv = DrawingService()

# 注册 explicit 命令，别名支持
drawing_cmd = on_command("画图", aliases={"绘图", "生成图片"}, priority=5, block=True)

@drawing_cmd.handle()
async def handle_drawing(bot: Bot, event: MessageEvent, args: Message = CommandArg()):
    prompt = args.extract_plain_text().strip()
    user_id = str(event.user_id)
    
    if not prompt:
        await drawing_cmd.finish("请在指令后加上描述哦，例如：画图 一只在月球上吃月饼的猫")

    await drawing_cmd.send(f"🎨 收到请求：{prompt}\n正在优化提示词并生成，请稍候...")

    # 调用 Service
    img_path, msg = await draw_srv.generate_image(prompt, user_id)
    
    if img_path:
        # 发送图片
        await drawing_cmd.finish(MessageSegment.image(f"file:///{img_path}") + msg)
    else:
        # 发送错误信息
        await drawing_cmd.finish(msg)