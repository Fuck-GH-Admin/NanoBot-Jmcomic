# src/plugins/chatbot/matchers/group_chat.py

import asyncio
from nonebot import on_message
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent, MessageSegment
from nonebot.params import EventPlainText
from nonebot.log import logger
from nonebot.exception import FinishedException

from..utils.string_utils import StringUtils
from..consts import SHORT_MESSAGE_REPLIES

# 从 services 包直接导入已经实例化好的对象
from ..services import img_srv, llm_srv, book_srv, draw_srv

# 优先级 10
group_chat = on_message(priority=10, block=False)

@group_chat.handle()
async def dispatch_logic(bot: Bot, event: GroupMessageEvent, text: str = EventPlainText()):
    # 1. 基础过滤
    if not event.is_tome():
        return
    
    text = text.strip()
    if not text:
        await group_chat.finish("🤔 发空气干嘛？")
        return

    user_id = str(event.user_id)
    
    # 2. 快速路径 A：短语匹配
    for kw, replies in SHORT_MESSAGE_REPLIES.items():
        if StringUtils.fuzzy_match(text, kw):
            import random
            await group_chat.finish(random.choice(replies))

    # 3. 快速路径 B：特定硬编码彩蛋 (苦命鸳鸯)
    if "苦命鸳鸯" in text:
        # [修改点] Service 内部现在接管了上传逻辑，直接调用即可
        try:
            msg = await book_srv.handle_bitter_lovebirds(bot, event.group_id)
            await group_chat.finish(msg)
        except Exception as e:
            logger.error(f"彩蛋触发失败: {e}")
            await group_chat.finish("彩蛋触发失败 QAQ")
        return

    # 4. 核心路径：基于 LLM 的意图分发
    try:
        intent = await asyncio.wait_for(
            llm_srv.fix_command(text), 
            timeout=8.0
        )
    except asyncio.TimeoutError:
        logger.warning(f"LLM fix_command timeout for user {user_id}")
        intent = {"action": "chat", "confidence": 0}
    except Exception as e:
        logger.error(f"LLM Intent Error: {e}")
        intent = {"action": "chat", "confidence": 0}

    action = intent.get("action", "chat")
    cmd = intent.get("fixed_command", text)
    confidence = intent.get("confidence", 0.0)
    
    logger.info(f" User:{user_id} | Action:{action} | Conf:{confidence}")

    # 5. 动态路由
    threshold = 0.6
    
    try:
        if action == "drawing" and confidence > threshold:
            await _handle_drawing(bot, event, cmd)
            
        elif action == "send_image" and confidence > threshold:
            await _handle_image_request(bot, event, cmd)
            
        elif action == "recommend_book" and confidence > threshold:
            await _handle_book_request(bot, event)
            
        elif action == "jm_download" and confidence > threshold:
            await _handle_jm_download(bot, event, cmd)
            
        elif action == "show_help":
            await _handle_help(event)
            
        else:
            await _handle_chat(bot, event, text)
            
    except FinishedException:
        raise
    except Exception as e:
        logger.error(f" Unhandled Exception: {e}")
        await group_chat.finish(f"执行出错了QAQ: {str(e)}")

# ================= 子处理函数 =================

async def _handle_drawing(bot: Bot, event: GroupMessageEvent, text: str):
    await group_chat.send("🎨 收到绘图请求，AI正在构思...")
    prompt = text.replace("画图", "").replace("绘图", "").strip()
    if not prompt: prompt = text 
    
    path, msg = await draw_srv.generate_image(prompt, str(event.user_id))
    if path:
        await group_chat.finish(MessageSegment.image(f"file:///{path}") + msg)
    else:
        await group_chat.finish(msg)

async def _handle_image_request(bot: Bot, event: GroupMessageEvent, text: str):
    allow_r18 = True 
    
    if "图" in text and any(c.isdigit() for c in text):
        paths, info = await img_srv.get_multi_images(text, allow_r18)
        if not paths:
            await group_chat.finish(info)
        
        await group_chat.send(info)
        for p in paths:
            stealth = await img_srv.generate_stealth(p)
            await group_chat.send(MessageSegment.image(f"file:///{stealth}"))
        await group_chat.finish()
    else:
        path, info = await img_srv.get_image(text, allow_r18)
        if path:
            stealth = await img_srv.generate_stealth(path)
            await group_chat.finish(MessageSegment.image(f"file:///{stealth}") + info)
        else:
            await group_chat.finish(info)

async def _handle_book_request(bot: Bot, event: GroupMessageEvent):
    # 直接调用 Repo 获取随机书
    path = book_srv.repo.get_random_book()
    
    if path:
        try:
            await bot.upload_group_file(
                group_id=event.group_id, 
                file=str(path), 
                name=path.name
            )
            await group_chat.finish(f"📖 随手拿了一本：{path.stem}")
        except Exception as e:
            await group_chat.finish(f"发送文件失败: {e}")
    else:
        await group_chat.finish("书架是空的，什么也没找到。")

async def _handle_jm_download(bot: Bot, event: GroupMessageEvent, text: str):
    import re
    ids = re.findall(r'\d+', text)
    if ids:
        await group_chat.send(f"⏳ 正在调度下载任务: {ids}")
        # [修改点] 适配 Service 新参数，指定 message_type="group"
        res = await book_srv.handle_jm_download(
            bot=bot, 
            target_id=event.group_id, 
            message_type="group", 
            ids=ids
        )
        await group_chat.finish(res)
    else:
        await group_chat.finish("没有识别到有效的数字ID哦")

async def _handle_help(event: GroupMessageEvent):
    msg = (
        "【Bot 功能列表】\n"
        "1. 聊天: @我\n"
        "2. 搜图: 发图 [关键词]\n"
        "3. 画图: 画图 [描述]\n"
        "4. 书籍: 来本书 / 苦命鸳鸯\n"
        "5. 下载: /jm\n"
        "6. 管理: 踢/禁言/审计 (仅管理员)"
    )
    await group_chat.finish(msg)

async def _handle_chat(bot: Bot, event: GroupMessageEvent, text: str):
    user_id = str(event.user_id)
    response = await llm_srv.chat(user_id, text)
    await group_chat.finish(response)