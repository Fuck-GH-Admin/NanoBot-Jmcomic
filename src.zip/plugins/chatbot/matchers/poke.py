from nonebot import on_notice
from nonebot.adapters.onebot.v11 import Bot, PokeNotifyEvent, MessageSegment
from nonebot.log import logger
import random
from datetime import datetime, timedelta

from ..consts import POKE_REPLIES
from ..services.image_service import ImageService
from ..config import plugin_config

img_srv = ImageService()

poke = on_notice(priority=5, block=True)

# 简单的内存状态管理 {user_id: {"count": int, "last_time": datetime, "last_reply": str}}
user_state = {}

# 特殊回复对应的动作映射
SPECIAL_ACTIONS = {
    "戳我也没用，我不会给你发图的！": "send_image",
    "都说了戳我也没用，还戳": "send_image",
    "好痒！停下！我要叫主人了！": "call_master",
    "你再戳我就把你禁言一分钟哦～": "warn_ban"
}

@poke.handle()
async def handle_poke(bot: Bot, event: PokeNotifyEvent):
    # 只响应戳机器人的事件
    if event.target_id != event.self_id:
        return

    user_id = event.user_id
    now = datetime.now()

    # 初始化或重置状态 (超时30秒重置)
    if user_id not in user_state:
        user_state[user_id] = {"count": 0, "last_time": now, "last_reply": None}
    
    state = user_state[user_id]
    if now - state["last_time"] > timedelta(seconds=30):
        state["count"] = 0
        state["last_reply"] = None
    
    state["last_time"] = now
    state["count"] += 1

    # === 检查是否触发后续动作 ===
    last_reply = state.get("last_reply")
    if last_reply in SPECIAL_ACTIONS:
        action = SPECIAL_ACTIONS[last_reply]
        
        # 动作：发图
        if action == "send_image":
            await poke.send("哼！给你发一张就是啦～")
            # 调用 ImageService 获取一张随机图
            path, _ = await img_srv.get_image("", allow_r18=False) 
            if path:
                await poke.finish(MessageSegment.image(f"file:///{path}"))
            state["count"] = 0
            state["last_reply"] = None
            return

        # 动作：禁言警告/执行
        elif action == "warn_ban":
            if state["count"] >= 3:
                if event.group_id:
                    try:
                        await bot.set_group_ban(group_id=event.group_id, user_id=user_id, duration=60)
                        await poke.finish("哼！让你戳！禁言1分钟！")
                    except Exception:
                        await poke.finish("呜呜…我没权限禁言你QAQ")
                state["count"] = 0
                state["last_reply"] = None
                return

        # 动作：叫主人
        elif action == "call_master":
            master_qq = list(plugin_config.superusers)[0] if plugin_config.superusers else "2797364016"
            await poke.finish(MessageSegment.at(master_qq) + f" 主人救命！{user_id} 老戳我！！")
            state["count"] = 0
            state["last_reply"] = None
            return

    # === 随机回复 ===
    reply = random.choice(POKE_REPLIES)
    
    # 记录特殊状态
    if reply in SPECIAL_ACTIONS:
        state["last_reply"] = reply
        # 如果是禁言警告，重置计数器以便从1开始数
        if SPECIAL_ACTIONS[reply] == "warn_ban":
            state["count"] = 1
    else:
        state["last_reply"] = None

    await poke.finish(reply)