# src/plugins/chatbot/matchers/private_chat.py

from nonebot import on_message
from nonebot.adapters.onebot.v11 import Bot, PrivateMessageEvent, MessageSegment
from nonebot.params import EventPlainText
from nonebot.rule import Rule
from nonebot.log import logger

from ..services.permission_service import PermissionService
from ..services.llm_service import LLMService
from ..services.image_service import ImageService
from ..services.book_service import BookService
from ..services.drawing_service import DrawingService
from ..consts import SHORT_MESSAGE_REPLIES

# 实例化服务
perm_srv = PermissionService()
llm_srv = LLMService()
img_srv = ImageService()
book_srv = BookService()
draw_srv = DrawingService()

# 定义权限规则 Rule
async def private_check(event: PrivateMessageEvent) -> bool:
    user_id = str(event.user_id)
    is_whitelisted = perm_srv.is_private_whitelisted(user_id)
    is_friend = getattr(event, "sub_type", "") == "friend"
    return is_whitelisted or is_friend

private_chat = on_message(rule=Rule(private_check), priority=1, block=True)

@private_chat.handle()
async def handle_private(bot: Bot, event: PrivateMessageEvent, text: str = EventPlainText()):
    text = text.strip()
    if not text: return
    user_id = str(event.user_id)

    # 1. 特殊彩蛋：苦命鸳鸯 (私聊仍建议禁用，或者需要修改逻辑，保持禁用以引导去群聊)
    if text == "苦命鸳鸯":
        await private_chat.finish("⚠️ 苦命鸳鸯功能建议在群聊中使用，方便分享~")
        return

    # 2. 短消息回复
    if text in SHORT_MESSAGE_REPLIES:
        import random
        await private_chat.finish(random.choice(SHORT_MESSAGE_REPLIES[text]))

    # 3. 意图识别
    try:
        intent = await llm_srv.fix_command(text)
    except:
        intent = {"action": "chat"}
        
    action = intent.get("action", "chat")
    cmd = intent.get("fixed_command", text)
    confidence = intent.get("confidence", 0)

    # 4. 路由
    if action == "drawing" and confidence > 0.6:
        await private_chat.send("🎨 绘图请求处理中...")
        prompt = cmd.replace("画图", "").strip()
        img_path, msg = await draw_srv.generate_image(prompt, user_id)
        if img_path:
            await private_chat.finish(MessageSegment.image(f"file:///{img_path}") + msg)
        else:
            await private_chat.finish(msg)

    elif action == "send_image" and confidence > 0.6:
        path, info = await img_srv.get_image(cmd, allow_r18=True)
        if path:
             await private_chat.finish(MessageSegment.image(f"file:///{path}") + info)
        else:
             await private_chat.finish(info)

    # [新增] 书籍推荐逻辑
    elif action == "recommend_book" and confidence > 0.6:
        path = book_srv.repo.get_random_book()
        if path:
            try:
                # 使用私聊上传文件接口
                await bot.upload_private_file(
                    user_id=event.user_id,
                    file=str(path),
                    name=path.name
                )
                await private_chat.finish(f"📖 悄悄塞给你一本：{path.stem}")
            except Exception as e:
                await private_chat.finish(f"发送文件失败: {e}")
        else:
            await private_chat.finish("书架是空的，什么也没找到。")

    # [修改] JM 下载逻辑 (支持私聊)
    elif action == "jm_download" and confidence > 0.6:
        import re
        ids = re.findall(r'\d+', cmd)
        if ids:
            await private_chat.send(f"⏳ [私聊] 正在调度下载任务: {ids}")
            # 调用 Service，指定 message_type="private"
            res = await book_srv.handle_jm_download(
                bot=bot, 
                target_id=event.user_id, 
                message_type="private", 
                ids=ids
            )
            await private_chat.finish(res)
        else:
            await private_chat.finish("没有识别到有效的数字ID哦")

    # 5. 兜底 AI 聊天
    resp = await llm_srv.chat(user_id, text)
    await private_chat.finish(resp)