from nonebot import on_notice
from nonebot.adapters.onebot.v11 import Bot, GroupIncreaseNoticeEvent, GroupDecreaseNoticeEvent, MessageSegment
from nonebot.log import logger
import asyncio

from ..config import plugin_config
from ..services.llm_service import LLMService

llm_srv = LLMService()
welcome = on_notice(priority=5, block=False)

async def check_welcome_enabled(group_id: str) -> bool:
    # 如果配置为空，默认对所有群生效；否则检查群号是否在配置中
    if not plugin_config.welcome_groups:
        return True
    return group_id in plugin_config.welcome_groups

@welcome.handle()
async def handle_increase(bot: Bot, event: GroupIncreaseNoticeEvent):
    if event.user_id == event.self_id: return
    
    # 检查模式 (hello 或 all)
    if plugin_config.welcome_mode not in ["hello", "all"]: return
    if not await check_welcome_enabled(str(event.group_id)): return

    try:
        # 使用 LLM 生成欢迎语
        # 这里直接构造一个简单的 Prompt，也可以封装进 LLMService
        prompt = "用可爱温暖的语气欢迎一位新朋友加入群聊，30字以内，可以加表情"
        # 复用 llm_srv 底层调用，或者在 llm_srv 中增加 generate_welcome_msg 方法
        # 这里假设 llm_srv 暴露了 _call_api 或者我们可以直接用 chat 方法
        # 为了规范，建议在 Service 层处理，这里演示直接调用 chat 接口（模拟无上下文对话）
        
        # 注意：这里我们使用一个虚拟的用户ID "system" 来避免污染真实用户记忆
        reply = await llm_srv.chat("system_welcome", prompt)
        
        msg = MessageSegment.at(event.user_id) + f" {reply}"
        await asyncio.sleep(1) # 稍作延迟
        await welcome.finish(msg)
    except Exception as e:
        logger.error(f"[Welcome] Failed to generate welcome msg: {e}")
        # 降级处理
        await welcome.finish(MessageSegment.at(event.user_id) + " 欢迎新朋友加入～")

@welcome.handle()
async def handle_decrease(bot: Bot, event: GroupDecreaseNoticeEvent):
    if event.user_id == event.self_id: return
    
    # 检查模式 (bye 或 all)
    if plugin_config.welcome_mode not in ["bye", "all"]: return
    if not await check_welcome_enabled(str(event.group_id)): return

    try:
        # 获取用户昵称 (如果能获取到)
        try:
            member_info = await bot.get_group_member_info(group_id=event.group_id, user_id=event.user_id)
            name = member_info.get("nickname", "群友")
        except:
            name = "一位群友"

        prompt = f"用有点伤感但不过分的语气说再见，提到“{name}”，25字以内"
        reply = await llm_srv.chat("system_welcome", prompt)
        
        await welcome.finish(reply)
    except Exception:
        await welcome.finish(f"{name} 离开了大家庭...常回来看看哦")