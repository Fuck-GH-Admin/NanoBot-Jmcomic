# src/plugins/chatbot/services/__init__.py

from .llm_service import LLMService
from .image_service import ImageService
from .drawing_service import DrawingService
from .book_service import BookService
from .permission_service import PermissionService

# === 全局单例实例 ===
# 只有在这里实例化，其他文件只导入这些实例，不要自己加括号调用
llm_srv = LLMService()
img_srv = ImageService()
draw_srv = DrawingService()
book_srv = BookService()
perm_srv = PermissionService()

__all__ = [
    "llm_srv", 
    "img_srv", 
    "draw_srv", 
    "book_srv", 
    "perm_srv"
]