# src/plugins/chatbot/services/drawing_service.py

import aiohttp
import asyncio
from typing import Tuple
from pathlib import Path
from datetime import datetime
from nonebot.log import logger

from..config import plugin_config
from..services.llm_service import LLMService

class DrawingService:
    """
    AI 绘图服务
    整合 Prompt 优化与 SiliconFlow API 调用
    """
    
    def __init__(self):
        self.llm_srv = LLMService()
        self.image_dir = Path("data/generated_images")
        self.image_dir.mkdir(parents=True, exist_ok=True)
        
        self.api_key = plugin_config.siliconflow_api_key
        self.api_url = plugin_config.siliconflow_api_url

    async def generate_image(self, simple_prompt: str, user_id: str) -> Tuple[str, str]:
        """
        生成图片的主入口
        :return: (本地文件路径, 提示信息)
        """
        # 1. 权限检查 (白名单)
        if user_id not in plugin_config.drawing_whitelist:
            return "", "❌ 你没有绘图权限，请联系管理员~"

        # 2. 提示词优化 (LLM)
        logger.info(f" Optimizing prompt: {simple_prompt}")
        try:
            # 增加超时控制
            enhanced_prompt = await asyncio.wait_for(
                self.llm_srv.enhance_drawing_prompt(simple_prompt), 
                timeout=15.0
            )
        except asyncio.TimeoutError:
            enhanced_prompt = simple_prompt # 降级策略
        
        logger.info(f" Enhanced: {enhanced_prompt}")

        # 3. 调用绘图 API
        try:
            path = await self._call_siliconflow(enhanced_prompt, user_id)
            if path:
                return path, f"✅ 绘图完成！\nPrompt: {enhanced_prompt[:30]}..."
            else:
                return "", "❌ 生成失败，API 返回了错误。"
        except Exception as e:
            logger.error(f" API Error: {e}")
            return "", f"❌ 发生错误: {e}"

    async def _call_siliconflow(self, prompt: str, user_id: str) -> str:
        """
        异步调用 SiliconFlow API
        使用 aiohttp 而非同步的 openai client
        """
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": plugin_config.siliconflow_model_name, # 或配置中的模型
            "prompt": prompt,
            "image_size": "1024x1024",
            "num_inference_steps": 20
        }

        async with aiohttp.ClientSession() as session:
            # 1. 请求生成
            async with session.post(
                f"{self.api_url}/images/generations", 
                json=payload, 
                headers=headers
            ) as resp:
                if resp.status!= 200:
                    err = await resp.text()
                    logger.error(f" API Error {resp.status}: {err}")
                    return ""
                
                data = await resp.json()
                
                # --- 修改开始 ---
                # SiliconFlow/OpenAI 格式通常是 { "data": [ { "url": "..." } ] }
                data_list = data.get("data", [])
                if data_list and isinstance(data_list, list):
                    # 取列表第一个元素，再 get url
                    img_url = data_list[0].get("url")
                else:
                    img_url = None
                # --- 修改结束 ---
                
                if not img_url:
                    logger.error(f"API returned no URL. Raw data: {data}")
                    return ""

            # 2. 下载图片
            async with session.get(img_url) as img_resp:
                if img_resp.status == 200:
                    content = await img_resp.read()
                    
                    # 保存文件
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                    filename = f"{user_id}_{timestamp}.png"
                    file_path = self.image_dir / filename
                    
                    # 异步写入
                    # 这里文件不大，aiofiles 带来的开销可能比收益大，但为了统一风格可用
                    # 或直接使用 blocking write (SSD上极快)
                    with open(file_path, "wb") as f:
                        f.write(content)
                        
                    return str(file_path.resolve())
        return ""