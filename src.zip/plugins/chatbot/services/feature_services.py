import random
import asyncio
from pathlib import Path
from typing import Optional, Tuple
from nonebot.log import logger
from..config import plugin_config
from..utils.pdf_utils import PDFUtils

class BookService:
    def __init__(self):
        self.books_dir = Path(plugin_config.books_folder)
        self.output_dir = self.books_dir / "output"
        self.output_dir.mkdir(parents=True, exist_ok=True)

    async def get_book(self, keyword: str = "") -> Tuple[Optional[Path], str]:
        if not self.books_dir.exists(): return None, "书架不存在"
        
        files = list(self.books_dir.glob("*.*"))
        # 彩蛋逻辑：苦命鸳鸯
        if keyword == "苦命鸳鸯":
            targets = [f for f in files if "350234" in f.name or "350235" in f.name]
            return (targets, "这何尝不是一种苦命鸳鸯") if targets else (None, "")
            
        target = random.choice(files)
        msg = "偷偷塞给你一本~"
        
        # 压缩包转 PDF
        if target.suffix in {'.zip', '.rar'}:
            pdf_path = self.output_dir / (target.stem + ".pdf")
            if not pdf_path.exists():
                loop = asyncio.get_running_loop()
                await loop.run_in_executor(None, PDFUtils.convert_zip_to_pdf, str(target), str(self.output_dir))
            if pdf_path.exists():
                target = pdf_path
                msg = "(已自动转PDF)"
                
        return target, msg

class DrawingService:
    async def generate_image(self, prompt: str, user_id: str) -> str:
        if user_id not in plugin_config.drawing_whitelist:
            return "❌ 你没有绘图权限"
        # 此处应调用 SiliconFlow API，代码结构同 LLMService
        return "🎨 绘图请求已发送（模拟）"