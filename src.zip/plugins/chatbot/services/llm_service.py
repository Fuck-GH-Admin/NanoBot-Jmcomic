import json
import re
import asyncio
import httpx
from typing import List, Dict, Any, Optional
from nonebot.log import logger

from ..config import plugin_config
from ..consts import CHAT_SYSTEM_PROMPT, COMMAND_FIX_PROMPT, DRAWING_ENHANCE_PROMPT
from ..repositories.memory_repo import MemoryRepository

class LLMService:
    """
    大模型服务
    负责对话生成、指令修复、记忆总结与提示词优化
    """
    def __init__(self):
        self.repo = MemoryRepository()
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {plugin_config.deepseek_api_key}"
        }
        self.summary_interval = 40  # 触发总结的对话轮数阈值

    async def _call_api(self, messages: List[Dict], timeout: float = 30.0, model: str = None) -> str:
        use_model = model if model else plugin_config.deepseek_model_name
        data = {
            "model": use_model,
            "messages": messages,
            "stream": False,
            "temperature": 1.3
        }
        try:
            async with httpx.AsyncClient(timeout=timeout) as client:
                resp = await client.post(plugin_config.deepseek_api_url, json=data, headers=self.headers)
                
                if resp.status_code != 200:
                    logger.error(f"[LLM] API Error {resp.status_code}: {resp.text}")
                    return ""

                resp.raise_for_status()
                return resp.json()["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.error(f"[LLM] API Call Failed: {e}")
            return ""

    async def chat(self, user_id: str, text: str) -> str:
        """
        RAG 风格对话：加载记忆 -> 构造 Prompt -> 调用 -> 保存 -> 触发总结
        """
        # 1. 加载记忆
        mem = await self.repo.load_memory(user_id)
        history = mem["history"]
        profile = mem["profile"]

        # 2. 构造 System Prompt (注入用户画像)
        system_text = CHAT_SYSTEM_PROMPT
        if profile:
            profile_str = json.dumps(profile, ensure_ascii=False, indent=2)
            system_text += f"\n\n【记住关于用户的信息(非必要不提及)】\n{profile_str}"

        messages = [{"role": "system", "content": system_text}]
        messages.extend(history[-20:])
        messages.append({"role": "user", "content": text})

        # 3. 调用 API
        reply = await self._call_api(messages)
        if not reply:
            return "呜呜...网络好像断开了..."

        # 4. 更新历史
        new_history_entry = [
            {"role": "user", "content": text},
            {"role": "assistant", "content": reply}
        ]
        history.extend(new_history_entry)

        # 5. 异步保存 & 检查是否需要总结
        asyncio.create_task(self._post_chat_process(user_id, history, profile))
        
        return reply

    def _quick_match_intent(self, text: str) -> Optional[Dict[str, Any]]:
        """
        [新增] 快速规则匹配
        用于拦截格式规范的指令，避免浪费 API Token 并提高响应速度
        """
        text = text.strip()
        lower_text = text.lower()

        # --- 1. 画图指令 (Drawing) ---
        # 匹配: "画图 xxx", "绘图 xxx", "画画 xxx"
        draw_prefixes = ("画图", "绘图", "画画", "生成图片")
        if text.startswith(draw_prefixes):
            # 提取描述内容，标准化为 "画图 [desc]"
            for p in draw_prefixes:
                if text.startswith(p):
                    content = text[len(p):].strip()
                    # 即使 content 为空也放行，由 DrawingService 处理提示
                    return {
                        "action": "drawing",
                        "fixed_command": f"画图 {content}",
                        "confidence": 1.0
                    }

        # --- 2. 搜图/发图指令 (Send Image) ---
        # 匹配: "发图", "涩图", "r18", "来张图" (开头匹配)
        img_prefixes = ("发图", "发个图", "来张图", "涩图", "色图", "r18", "r18g", "极端", "重口")
        # 匹配以这些词开头，后面跟空格或其他内容的
        for p in img_prefixes:
            if lower_text == p.lower() or lower_text.startswith(p.lower() + " "):
                return {
                    "action": "send_image",
                    "fixed_command": text, # 保留原文以便 ImageService 提取关键词
                    "confidence": 1.0
                }
        
        # 匹配特殊的多图语法: "图1-3", "图5" (只要包含这种模式就认为是发图)
        if re.search(r'图\s*\d+', text):
             return {
                "action": "send_image",
                "fixed_command": text,
                "confidence": 1.0
            }

        # --- 3. JM 下载指令 (JM Download) ---
        # 匹配: "/jm 123", "jm 123 456", "下载本子 123"
        # 正则含义：以 (jm/下载本子) 开头，后面紧跟至少一组数字
        if re.match(r'^(?:/)?(?:jm|下载本子)\s+(\d+\s*)+$', text, re.IGNORECASE):
            ids = re.findall(r'\d+', text)
            return {
                "action": "jm_download",
                "fixed_command": f"/jm {' '.join(ids)}",
                "confidence": 1.0
            }

        # --- 4. 书籍推荐 (Book) ---
        # 精确匹配
        if text in ["来本书", "好书推荐", "本", "发本", "本子", "推荐书", "看本书"]:
             return {
                "action": "recommend_book",
                "fixed_command": "来本书",
                "confidence": 1.0
            }

        # --- 5. 帮助菜单 (Help) ---
        if lower_text in ["菜单", "帮助", "help", "怎么用", "有什么功能", "指令"]:
            return {
                "action": "show_help",
                "fixed_command": "菜单",
                "confidence": 1.0
            }

        return None

    async def fix_command(self, text: str) -> Dict[str, Any]:
        """AI 指令修复 / 意图识别"""
        if not plugin_config.enable_ai_command_fixer:
            return {"action": "chat", "confidence": 0}

        # [新增] 0. 快速通道：规则匹配
        # 如果命中规则，直接返回，不再调用 DeepSeek
        quick_result = self._quick_match_intent(text)
        if quick_result:
            logger.info(f"[LLM] Quick Match Hit: {quick_result['action']}")
            return quick_result

        # 简单规则过滤：太短或太长不走 AI (短文本可能在上面已经命中规则，没命中的大概率是聊天)
        if len(text) < 2 or len(text) > 300:
            return {"action": "chat", "confidence": 0}

        # 1. 慢速通道：LLM 意图识别
        messages = [
            {"role": "system", "content": COMMAND_FIX_PROMPT},
            {"role": "user", "content": text}
        ]
        
        logger.debug(f"[LLM] Quick Match Miss, calling API for: {text}")
        resp = await self._call_api(messages, timeout=plugin_config.ai_command_timeout)
        
        if not resp:
            logger.warning("[LLM] fix_command received empty response")
            return {"action": "chat", "confidence": 0}

        # 解析 JSON
        try:
            json_str = re.search(r"\{.*\}", resp, re.DOTALL).group(0)
            result = json.loads(json_str)
            return result
        except Exception as e:
            logger.warning(f"[LLM] Command fix parsing failed: {e}")
            return {"action": "chat", "confidence": 0}

    async def enhance_drawing_prompt(self, simple_prompt: str) -> str:
        """优化绘图提示词"""
        messages = [
            {"role": "system", "content": DRAWING_ENHANCE_PROMPT},
            {"role": "user", "content": simple_prompt}
        ]
        enhanced = await self._call_api(messages, timeout=15.0)
        return enhanced if enhanced else simple_prompt

    async def _post_chat_process(self, user_id: str, history: List[Dict], profile: Dict):
        """对话后处理：保存 + 自动总结"""
        if len(history) > self.summary_interval * 2:
            new_history, new_profile = await self._summarize_memory(history, profile)
            await self.repo.save_memory(user_id, new_history, new_profile)
        else:
            await self.repo.save_memory(user_id, history, profile)

    async def _summarize_memory(self, history: List[Dict], current_profile: Dict) -> tuple[List[Dict], Dict]:
        """
        核心逻辑：带权重的记忆提取与合并
        """
        logger.info("[LLM] Triggering memory summary...")
        prompt = (
            "请总结以下聊天记录，提取用户关键信息（称呼、喜好、背景等）。"
            "直接输出JSON，格式：\n"
            "{\n"
            '  "name": "用户昵称",\n'
            '  "key_info": [{"info": "事实", "weight": 1-10}],\n'
            '  "preferences": {"likes": [{"item": "x", "weight": 1-10}], "hates": [...]}\n'
            "}\n"
            f"历史记录：\n{json.dumps(history, ensure_ascii=False)}"
        )
        
        resp = await self._call_api([{"role": "user", "content": prompt}])
        
        try:
            json_str = re.search(r"\{.*\}", resp, re.DOTALL).group(0)
            new_data = json.loads(json_str)
            
            # === 智能合并逻辑 ===
            if new_data.get("name"): 
                current_profile["name"] = new_data["name"]

            current_info = {i["info"]: i for i in current_profile.get("key_info", [])}
            for item in new_data.get("key_info", []):
                key = item.get("info")
                weight = item.get("weight", 5)
                if key:
                    if key in current_info:
                        current_info[key]["weight"] = max(current_info[key]["weight"], weight)
                    else:
                        current_info[key] = item
            current_profile["key_info"] = list(current_info.values())
            
            return history[-4:], current_profile

        except Exception as e:
            logger.error(f"[LLM] Summary failed: {e}")
            return history, current_profile