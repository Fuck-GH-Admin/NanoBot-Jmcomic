# src/plugins/chatbot/services/permission_service.py

import re
import json
from typing import Optional, Set, List, Dict, Union, Literal
from nonebot.adapters.onebot.v11 import Bot, GroupMessageEvent
from nonebot.log import logger

from ..config import plugin_config
from ..services.llm_service import LLMService

class PermissionService:
    """
    权限与群管理核心服务
    
    职责：
    1. 统一鉴权：Superuser / AI Admin / Group Admin 判定。
    2. 执行管理操作：封装 Ban/Kick 等 API 调用，包含前置检查。
    3. 智能审计：基于 LLM 的违规内容判定。
    """
    
    def __init__(self):
        # 依赖注入 LLM 服务
        self.llm_service = LLMService()
        
        # 加载配置中的静态名单
        self.superusers: Set[str] = plugin_config.superusers
        self.ai_admin_qq: Set[str] = plugin_config.ai_admin_qq
        # 白名单机制
        self.private_whitelist: Set[str] = plugin_config.private_whitelist
        self.drawing_whitelist: Set[str] = plugin_config.drawing_whitelist

    # ================= 基础鉴权逻辑 =================

    def is_superuser(self, user_id: str) -> bool:
        """检查是否为最高权限宿主"""
        return user_id in self.superusers

    def is_ai_admin(self, user_id: str) -> bool:
        """检查是否为 Bot 维护管理员"""
        return user_id in self.ai_admin_qq

    def is_group_admin(self, sender_role: str) -> bool:
        """检查是否为群组管理员/群主 (OneBot 标准字段)"""
        return sender_role in ["owner", "admin"]

    def has_command_privilege(self, user_id: str, sender_role: str) -> bool:
        """
        综合权限检查：是否有权执行管理指令
        策略：宿主 OR 维护员 OR 群管理员
        """
        return (
            self.is_superuser(user_id) 
            or self.is_ai_admin(user_id) 
            or self.is_group_admin(sender_role)
        )

    def is_user_whitelisted(self, user_id: str, scope: Literal["private", "drawing"]) -> bool:
        """检查特定功能的白名单"""
        if scope == "private":
            return user_id in self.private_whitelist
        elif scope == "drawing":
            return user_id in self.drawing_whitelist
        return False

    # 【修复点】新增兼容方法，解决 matchers 调用报错
    def is_private_whitelisted(self, user_id: str) -> bool:
        """检查私聊白名单"""
        return self.is_user_whitelisted(user_id, "private")

    # ================= 业务执行逻辑 =================

    async def check_bot_admin_status(self, bot: Bot, group_id: int) -> bool:
        """
        检查 Bot 自身在群内是否具有管理员权限。
        这是执行所有管理操作的前置防御。
        """
        try:
            bot_member = await bot.get_group_member_info(
                group_id=group_id, 
                user_id=int(bot.self_id),
                no_cache=True
            )
            return bot_member.get("role") in ["owner", "admin"]
        except Exception as e:
            logger.error(f"[Permission] Failed to check bot status: {e}")
            # 悲观策略：如果查不到，假设没有权限，防止报错
            return False

    async def ban_user(
        self, 
        bot: Bot, 
        group_id: int, 
        target_id: int, 
        duration: int, 
        operator_id: str,
        reason: str = "Admin Command"
    ) -> str:
        """
        执行禁言操作（含层级检查）
        """
        # 1. Bot 权限自检
        if not await self.check_bot_admin_status(bot, group_id):
            return "❌ 我没有管理员权限，无法执行禁言操作。"

        # 2. 目标层级检查（防止禁言群主或其他管理员）
        try:
            target_info = await bot.get_group_member_info(group_id=group_id, user_id=target_id)
            if target_info.get("role") in ["owner", "admin"]:
                return f"❌ 无法禁言管理员 <{target_id}>，对方权限等级过高。"
        except Exception:
            # 目标可能已退群，但在 API 层面仍可尝试禁言（防诈尸）
            pass 

        # 3. 执行 API
        try:
            await bot.set_group_ban(
                group_id=group_id, 
                user_id=target_id, 
                duration=duration
            )
            logger.info(f" Op:{operator_id} -> Target:{target_id} | Dur:{duration}s | Reason:{reason}")
            
            if duration == 0:
                return f"✅ 已解除 <{target_id}> 的禁言。"
            else:
                return f"🚫 用户 <{target_id}> 已被禁言 {duration}秒。"
        except Exception as e:
            logger.error(f" Execution failed: {e}")
            return f"❌ 操作失败: {str(e)}"

    async def kick_user(self, bot: Bot, group_id: int, target_id: int, reject_add_request: bool = False) -> str:
        """执行踢人操作"""
        if not await self.check_bot_admin_status(bot, group_id):
            return "❌ 我没有管理员权限，无法踢人。"
            
        try:
            # 同样需要检查目标是否为管理员，OneBot API 通常会报错，但这里做预检更优雅
            target_info = await bot.get_group_member_info(group_id=group_id, user_id=target_id)
            if target_info.get("role") in ["owner", "admin"]:
                return "❌ 无法踢出群管理员。"

            await bot.set_group_kick(
                group_id=group_id, 
                user_id=target_id, 
                reject_add_request=reject_add_request
            )
            return f"👋 已将 <{target_id}> 移出群聊。"
        except Exception as e:
            logger.error(f"[Kick] Execution failed: {e}")
            return f"❌ 踢人失败: {e}"

    async def ai_audit_and_punish(self, bot: Bot, group_id: int, target_id: int) -> str:
        """
        AI 智能审计：拉取用户最近发言，判断是否违规，若违规自动禁言。
        """
        # 1. 获取历史消息
        try:
            # 注意：get_group_msg_history 不是 OneBot V11 标准 API，通常是 go-cqhttp 扩展
            # 这里假设环境支持，或需根据实际 adapter 调整
            history = await bot.call_api("get_group_msg_history", group_id=group_id)
            messages = history.get("messages", [])
        except Exception as e:
            logger.warning(f"[Audit] Fetch history failed: {e}")
            return "❌ 获取聊天记录失败，无法进行 AI 审计。"

        # 2. 过滤目标用户的发言
        user_msgs = []
        for msg in messages:
            if str(msg.get("user_id")) == str(target_id):
                # 提取纯文本内容
                text_content = ""
                if isinstance(msg.get("message"), list):
                    for seg in msg["message"]:
                        if seg["type"] == "text":
                            text_content += seg["data"].get("text", "")
                elif isinstance(msg.get("message"), str):
                    text_content = msg["message"]
                
                if text_content:
                    user_msgs.append(text_content)
        
        if not user_msgs:
            return "❓ 该用户近期没有发言记录，AI 无法判断。"

        # 取最近 15 条
        evidence = "\n".join(user_msgs[:15])

        # 3. 构造 Prompt 调用 LLM
        prompt = (
            f"请审核以下用户的群聊发言，判断是否存在严重违规（如：色情、暴力、诈骗、恶意刷屏、人身攻击）。"
            f"忽略轻微的玩笑。直接返回JSON格式：{{\"violation\": true/false, \"reason\": \"原因\", \"suggested_duration\": 秒数}}\n"
            f"用户发言：\n{evidence}"
        )

        try:
            # 调用 LLM 服务
            response_text = await self.llm_service.chat("system_audit", prompt) 
            
            # 解析 JSON
            match = re.search(r"\{.*\}", response_text, re.DOTALL)
            if match:
                result = json.loads(match.group(0))
            else:
                return "❌ AI 返回格式异常，审计中止。"

            if result.get("violation"):
                duration = result.get("suggested_duration", 600)
                reason = result.get("reason", "AI判定违规")
                # 执行惩罚
                ban_msg = await self.ban_user(bot, group_id, target_id, duration, "AI_AUDIT", reason)
                return f"🤖 AI 审计判定违规。\n理由：{reason}\n执行结果：{ban_msg}"
            else:
                return f"🤖 AI 审计判定未违规。\n理由：{result.get('reason')}"

        except Exception as e:
            logger.error(f"[Audit] AI processing failed: {e}")
            return f"❌ AI 审计过程出错: {e}"

    def parse_duration(self, text: str) -> int:
        """
        解析自然语言时间描述。
        支持：'10分钟', '1小时', '30s', '1天'
        """
        if not text: return 1800 # 默认 30分钟
        
        text = text.lower().strip()
        multipliers = {
            "秒": 1, "s": 1, "sec": 1,
            "分": 60, "min": 60, "m": 60,
            "小时": 3600, "hour": 3600, "h": 3600, "钟": 3600, # 兼容 '1小时'
            "天": 86400, "day": 86400, "d": 86400
        }
        
        # 匹配 数字 + 单位
        match = re.search(r'(\d+)\s*([\u4e00-\u9fa5a-z]+)?', text)
        if match:
            value = int(match.group(1))
            unit = match.group(2)
            
            if not unit: 
                return value * 60 # 纯数字默认为分钟
            
            for key, mult in multipliers.items():
                if key in unit:
                    return min(value * mult, 2592000) # 上限 30天 (OneBot限制)
        
        return 1800